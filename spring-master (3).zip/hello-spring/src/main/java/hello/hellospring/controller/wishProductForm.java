//package hello.hellospring.controller;
//
//public class wishProductForm {
//    private String wishproductname;
//
//    public String getWishproductname() {
//        return wishproductname;
//    }
//
//    public void setWishproductname(String wishproductname) {
//        this.wishproductname = wishproductname;
//    }
//
//}
