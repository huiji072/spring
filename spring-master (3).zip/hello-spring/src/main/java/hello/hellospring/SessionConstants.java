package hello.hellospring;

public interface SessionConstants {
    String LOGIN_MEMBER = "loginMember";
}
